-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 11, 2026 at 11:53 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zenblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int NOT NULL,
  `c_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_stastus` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`, `c_desc`, `c_stastus`) VALUES
(1, 'Tech', 'Tech', 1),
(2, 'Food', 'Food', 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `p_id` int NOT NULL,
  `p_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `p_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `p_users` int DEFAULT NULL,
  `p_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_status` int DEFAULT '0',
  `p_link` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`p_id`, `p_title`, `p_desc`, `p_users`, `p_date`, `p_category`, `p_status`, `p_link`) VALUES
(4, 'Hewlett Packard', 'The Hewlett-Packard Company, commonly shortened to Hewlett-Packard (/ˈhjuːlɪt ˈp&aelig;kərd/ HEW-lit PAK-ərd) or HP, was an American multinational information technology company. It was founded by Bill Hewlett and David Packard in 1939 in a one-car garage in Palo Alto, California. Growing to become an influential high-tech powerhouse at the heart of Silicon Valley, the company was known for its progressive business philosophy, deemed the HP Way. HP developed and provided a wide variety of hardware components, as well as software and related services, to consumers, small and medium-sized businesses (SMBs), and fairly large companies, including customers in government sectors. At its peak in 2011, HP employed 350,000 people around the globe.[2] The company officially split into Hewlett Packard Enterprise and HP Inc. in 2015.\r\n\r\nHP initially produced a line of electronic test and measurement equipment. It won its first big contract in 1938 to provide the HP 200B, a variation of its first product, the HP 200A low-distortion frequency oscillator,[3] for Walt Disney&#039;s production of the 1940 animated film Fantasia, which allowed Hewlett and Packard to formally establish the Hewlett-Packard Company on July 2, 1939.[4] The company grew into a multinational corporation widely respected for its products. HP was the world&#039;s leading PC manufacturer from 2007 until the second quarter of 2013 when Lenovo moved ahead of HP.[5][6][7] HP specialized in developing and manufacturing computing, data storage, and networking hardware, designing software, and delivering services. Major product lines included personal computing devices, enterprise and industry standard servers, related storage devices, networking products, software, and a range of printers and other imaging products. The company directly marketed its products to households, small- to medium-sized businesses, and enterprises, as well as via online distribution, consumer-electronics, and office-supply retailers, software partners, and major technology vendors. It also offered services and a consulting business for its products and partner products.\r\n\r\nIn 1999, HP spun off its electronic and bio-analytical test and measurement instruments business into Agilent Technologies; HP retained focus on its later products, including computers and printers. It merged with Compaq in 2002 in what was then a major deal within the industry.[8] They made numerous other acquisitions including Electronic Data Systems in 2008, which led to combined revenues of $118.4 billion that year and a Fortune 500 ranking of 9 in 2009, and later 3Com,[9][10] Palm, Inc.,[11] and 3PAR, all in 2010,[12] followed by Autonomy Corp.[13] However, as a result of the turmoil created by several of these acquisitions, the company&#039;s fortunes swiftly declined in the 2010s.[14][15] This led to Hewlett-Packard Company&#039;s split into two separate companies on November 1, 2015: its enterprise products and services business were spun-off to form Hewlett Packard Enterprise, while its personal computer and printer businesses became HP Inc. The split was structured so that the former Hewlett-Packard Company would change its name to HP Inc. and spin off Hewlett Packard Enterprise as a newly created company. HP Inc. retained the old Hewlett-Packard&#039;s stock-price history and original NYSE ticker symbol; Hewlett Packard Enterprise trades under its own ticker symbol: HPE.[16][17]', NULL, '08-06-2026', '1', 0, NULL),
(5, 'tgtgt', 'gtgtgtgtg', NULL, '08-06-2026', '56', 0, NULL),
(6, 'edede', 'deede', NULL, '08-06-2026', '4554', 0, NULL),
(7, 'edede', 'deede', NULL, '08-06-2026', '4554', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int NOT NULL,
  `u_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `u_phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `u_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `u_password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `u_name`, `u_phone`, `u_email`, `u_password`) VALUES
(37, 'Karimun Nahar', '32145678654', 'pharaoh1822005@gmail.com', '223344'),
(38, 'Karimun Nahar', '32145678654', 'pharaoh1822005@gmail.com', '223344'),
(39, 'dsddfs', 'dsadsa', 'pharaoh1822005@gmail.com', 'fdgfdgfd'),
(40, 'dsddfs', 'dsadsa', 'pharaoh1822005@gmail.com', 'fdgfdgfd'),
(41, 'dsddfs', 'dsadsa', 'pharaoh1822005@gmail.com', 'fdgfdgfd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `p_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
