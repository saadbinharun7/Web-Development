-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 29, 2026 at 03:02 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zenblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int NOT NULL,
  `c_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_stastus` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`, `c_desc`, `c_stastus`) VALUES
(1, 'Tech', 'Tech', 1),
(2, 'Food', 'Food', 1),
(3, 'Health', 'Health', 1),
(4, 'BD', 'BD', 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `p_id` int NOT NULL,
  `p_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `p_desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `p_users` int DEFAULT NULL,
  `p_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_status` int DEFAULT '0',
  `p_link` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_img` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`p_id`, `p_title`, `p_desc`, `p_users`, `p_date`, `p_category`, `p_status`, `p_link`, `p_img`) VALUES
(12, 'How YouTube Changed the Way We Learn', 'Learning is no longer limited to classrooms and textbooks. YouTube offers millions of tutorials, lectures, and educational channels covering everything from programming and mathematics to cooking and photography. This article discusses how YouTube has become a powerful tool for self-education and lifelong learning.', 0, '15-06-2026', '1', 0, '', '97703.png'),
(13, 'The Evolution of YouTube', 'YouTube has transformed from a small video-sharing platform into one of the worlds largest entertainment and educational hubs. Since its launch in 2005, it has empowered creators, businesses, and educators to reach billions of viewers worldwide. This article explores YouTubes growth, its impact on digital culture, and how it continues to shape the future of online content.', 0, '15-06-2026', '1', 0, '', '57505.png'),
(14, 'The Rise of YouTube Content Creators', 'YouTube has created a new generation of digital entrepreneurs. Content creators can build communities, share their passions, and even earn a full-time income through their videos. This article examines the journey of YouTubers, the challenges they face, and the opportunities available in the creator economy.', 0, '15-06-2026', '4', 0, '', '89643.png'),
(15, 'aaaaaa', 'bbbbbbb', 0, '22-06-2026', '1', 0, '', '98906.png'),
(16, 'aaaaaa', 'bbbbbbb', 0, '22-06-2026', '1', 0, '', '98906.png'),
(17, 'What is there to teach a Kennedy about politics? As Jack Schlossberg has found out, a lot', 'The Justice Department is set to provide about two hours of recordings of Biden speaking to writer Mark Zwonitzer to the Republican-led House Judiciary Committee in the next three weeks, unless a court steps in to block the move, which would be unusual.\r\n\r\nBefore the House committee’s request for the tapes is resolved, the conservative Heritage Foundation already won a judge’s initial endorsement last week for the public release of the tapes.\r\n\r\nThe foundation hasn’t yet received the recordings or transcripts of them, however, because Biden is appealing. A federal trial-level judge has already paused the release of the tapes for three weeks, to allow the appellate court in DC time to weigh in.\r\n\r\nDC District Judge Dabney Friedrich — siding with the Heritage Foundation on Friday after listening to the tapes for herself — wrote that the Justice Department was within its abilities to decide to release the tapes now. She also said the Justice Department plans to redact parts of the tapes, and she decided “that Biden’s privacy arguments largely overlook the Department’s recent redactions and reasonings.”', 0, '22-06-2026', '1', 0, '', '27820.png'),
(18, 'World health Organization', 'The Justice Department is set to provide about two hours of recordings of Biden speaking to writer Mark Zwonitzer to the Republican-led House Judiciary Committee in the next three weeks, unless a court steps in to block the move, which would be unusual.\r\n', 0, '22-06-2026', '3', 0, '', '62130.png'),
(19, 'The Beautiful Game: Why Football Is the Worlds Most Popular Sport', 'Football is more than just a sport  it is a global phenomenon that unites millions of people across different cultures and nations. From local playgrounds to massive stadiums filled with passionate fans, football has the power to inspire, entertain, and bring communities together.\r\n\r\nOne of the biggest reasons for footballs popularity is its simplicity. All that is needed is a ball and an open space. This accessibility allows people of all ages and backgrounds to enjoy the game. Whether played professionally or casually among friends, football creates unforgettable moments and lifelong memories.\r\n\r\nThe sport also teaches valuable life lessons such as teamwork, discipline, perseverance, and leadership. Players learn to work together toward a common goal while overcoming challenges both on and off the field.\r\n\r\nAs football continues to grow worldwide, it remains a symbol of unity, passion, and the enduring spirit of competition.', 0, '22-06-2026', '1', 0, '', '74010.png'),
(20, 'Rising Stars: The Future of Football', 'Football is constantly evolving, and a new generation of talented young players is shaping the future of the sport. These rising stars are bringing incredible skill, speed, and creativity to the game, exciting fans around the world.\r\n\r\nYoung footballers are now receiving professional training from an early age, allowing them to develop their abilities faster than ever before. Many clubs invest heavily in youth academies to discover and nurture future superstars.\r\n\r\nModern football demands versatility, with players expected to contribute both offensively and defensively. As a result, young athletes are becoming more complete players, capable of adapting to different tactics and playing styles.\r\n\r\nWith emerging talents making headlines every season, the future of football looks brighter than ever. Fans can look forward to witnessing the next generation of legends take the sport to new heights.', 0, '22-06-2026', '4', 0, '', '73887.png'),
(21, 'The Beautiful Game: Why Football Is the Worlds Most Popular Sport', 'Education is one of the most powerful tools for personal and social development. It equips individuals with knowledge, skills, and values that help them succeed in life and contribute positively to society.\r\n\r\nA good education opens doors to better career opportunities and improves the quality of life. It enables people to think critically, solve problems, and make informed decisions. Educated individuals are more likely to participate actively in their communities and promote social progress.\r\n\r\nMoreover, education fosters creativity and innovation. In todays rapidly changing world, continuous learning is essential for adapting to new technologies and challenges. Schools and educational institutions play a vital role in preparing students for the future.\r\n\r\nIn conclusion, education is the foundation of a prosperous and progressive society. Investing in education benefits not only individuals but also entire nations.', 0, '22-06-2026', '2', 0, '', '9208.png'),
(22, 'Online Learning: Transforming the Future of Education', 'The rise of technology has transformed many aspects of life, including education. Online learning has become increasingly popular, offering students the flexibility to learn anytime and anywhere.\r\n\r\nOne of the greatest advantages of online education is accessibility. Students can access lectures, study materials, and assignments from their homes, eliminating geographical barriers. This has made quality education available to millions of learners worldwide.\r\n\r\nOnline learning also encourages self-discipline and independent study habits. Students can learn at their own pace, revisit lessons, and customize their learning experience according to their needs.\r\n\r\nDespite its many benefits, online education also presents challenges such as limited face-to-face interaction and the need for reliable internet access. However, with ongoing technological advancements, these challenges are gradually being addressed.', 0, '22-06-2026', '2', 0, '', '72057.png'),
(23, 'abcd', 'saudsaudasd', 40, '25-06-2026', '1', 0, '', '55843.png'),
(24, 'abcd', 'saudsaudasd', 40, '25-06-2026', '1', 0, '', '70123.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int NOT NULL,
  `u_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `u_phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `u_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `u_password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `u_name`, `u_phone`, `u_email`, `u_password`) VALUES
(37, 'Karimun Nahar', '123', 'pharaoh1822005@gmail.com', '223344'),
(40, 'ABDUL ALIM', '234', 'pharaoh1822005@gmail.com', '223344');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `p_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
